# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 16:42:41 2021

@author: Lenovo
"""

n = int(input())
for i in range(n):
    print(i+1,end="")