# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 16:18:00 2021

@author: Lenovo
"""

n = int(input())
i=0
while i<n:
    print(i**2)
    i+=1
