# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 11:28:03 2021

@author: Lenovo
"""

a=int(input())
b=int(input())
print(a+b)
print(a-b)
print(a*b)