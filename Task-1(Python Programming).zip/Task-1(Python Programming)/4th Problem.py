# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 12:11:12 2021

@author: Lenovo
"""

a = int(input())
b = int(input())
c=a//b
print(c)
print(a/b)