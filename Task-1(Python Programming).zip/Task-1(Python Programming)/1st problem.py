# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 10:01:12 2021

@author: Lenovo
"""

print("Hello, World!")


